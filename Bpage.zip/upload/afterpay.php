<?php

	$target_page = "thankyou.html";


header("Location: $target_page");
exit;

?>