﻿<?php
$path_escape = "";
require_once("initvars.inc.php");
require_once("config.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Payment cancelled</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<br><br><br><br>
<br><br><br><br>
<div align="center">
<div class="err">Payment has been cancelled</div>
<a href="index.php">Back to Main page</a>
</div>
</body>
</html>