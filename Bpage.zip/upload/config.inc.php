<?php
/*==================================================SET UP INFORMATION=======================================================*/
// MySQL connection settings
$db_host = "localhost";
$db_user = "FILL THIS PART WITH YOUR INFORMATION";
$db_pass = "FILL THIS PART WITH YOUR INFORMATION";
$db_name = "FILL THIS PART WITH YOUR INFORMATION";

// Your license ID
$id = "";

// The URL of the script (without trailing slashes) It must be the domain name you provided!
$script_url = "FILL THIS PART WITH YOUR INFORMATION";

// Name of the site
$site_name = "FILL THIS PART WITH YOUR INFORMATION";

// Site email address
$site_email = "FILL THIS PART WITH YOUR INFORMATION";



/*=================================================================================================================================*/

/*==================================================ADITIONAL SET UP INFORMATION===================================================*/
// The basename of the language file to use.
// There should be a file with this name and ".inc.php" as extension in the "lang" directory
$language = "en";

/*==============================
| ADMIN CONTACT FORM HISTORY ADDON START				
===============================*/

$msgs_per_page = 10;

/*==============================
| ADMIN CONTACT FORM HISTORY ADDON END	  			
===============================*/

$enable_extra_uploads = 1;

// Make your site offline - Online. Yes=Offline - No=Online 
$offline = "no";  

// Enabled the Related Ads mod. Default 1

$related_enabled = 1;

// Limit related to city only.  Only displays ads from related cities. Default 1

$related_city_limit = 0;

// Limit related ads to category only.  Only displays ads from related categories and subcategories. Default 0

$related_cat_limit = 0;

// Limit amount of keyword results.  Default 5

$relate_limit = 10;


// ID of the default city. If u want to use a region as default, 
// enter the region id preceeded with a '-'. Set this to 0 and 
// the first city in the database will be taken as the default.
$default_city = 0;

// Determine how many seconds sender should wait before emailing someone through

// the contact form if the ad poster enabled contact form. Default is 90.

$ad_contact_limit = 90;

// Max amount of emails sender can send within a 24 hour period.  Default is 20.

$ad_contact_max_count = 20;

// Amount of seconds to wait before DB removes old log of sender IP.

// IT IS RECOMMENDED NOT TO GO BEYOND 86400 seconds (1 day)

$ad_contact_db_empty = 86400;

// Automatically expire events and images after how many days. 
$expire_events_after = 90;
$expire_images_after = 90;

// Default days for which the ad will be running. You may speify 
// a different expiration time for each subcategory from the admin.
$expire_ads_after_default = 60;

// The amount of days set in advanced to email users with expiring ads.
// This format is in seconds (86400 = 1 day, 172,800 = 2 days, etc.).  Default is 7 days
$expire_ads_ahead = 432000;


// Select if you want the poster's Ad Creation Date to update when they renew their ad
// Default is 1 (enabled), Disabled is 0
$update_ad_creation = 1;


// Select if you want to receive an email whenever the expire cron is ran that provides details such as 
// how many emails were sent.
// Default is 0 (disabled), Enabled is 1
$reminder_email_master = 1;



// Enable or disable events or image posting. default is enable
// This will also enable or disable events and image display on the main page
$enable_calendar = TRUE;
$enable_images = TRUE;


// The amount of days set in advanced to renew ads from admin panel.

// This format is in days (1 = 1 day, 2 = 2 days, etc.).  Default is 30 days

$admin_renew_days = 30;

// Whether you want admin renew mod to update ad's creation date at time of renewal

// Set to 0 to disable.  Default is 1

$admin_renew_cre_dt = 1;

// Maximum number of abuse reports after which the ads are to be suspended.
// Should always be less than 99999. Set to 0 to disable.
$max_abuse_reports = 10;


//  Weather to display info panel on main page
// Set to FALSE to hide it
$info_panel = TRUE;


//  Weather to display advertisements
// Set to FALSE to hide it
$advert_manager = TRUE;

// Wether to use SE friendly URLs
// Requries .htaccess and mod_rewrite support
$sef_urls = TRUE;


// Word separator to use in search engine friendly URLs, if $sef_urls is enabled.
$sef_word_separator = "-";


// Wether to show the left sidebar on inner pages also (not recommmended)
$show_sidebar_always = FALSE;

// Wether to show the right sidebar
$show_right_sidebar = FALSE;

// Character to use as separator in the path shown on top of the page
$path_sep = " - ";

// Wether to sort cats and subcats alphabetically
$dir_sort = FALSE;

// Number of columns in the main directory. If you change to less than 3 then the layout might not look good.
$dir_cols = 4;

// Wether to show the ad count near the subcategory and main category
$show_cat_adcount = TRUE;
$show_subcat_adcount = FALSE;

// Wether to sort location alphabetically
$location_sort = FALSE;

// Number of columns for locations
$location_cols = 2;


// Wether to show the number of ads near regions and cities in the right sidebar
$show_region_adcount = TRUE;
$show_city_adcount = TRUE;

// Number of ads/events and images to show per page
$ads_per_page = 100;
$images_per_page = 10;

// Number of picture upload fields to show in post ad page
$pic_count = 4;

// Maximum size of pictures (in KB)
$pic_maxsize = 1000;

// MIME types of files that are to be accepted as images
$pic_filetypes = array("image/gif", "image/jpeg", "image/pjpeg", "image/png");
$image_extensions = array("gif", "jpg", "jpeg", "png");

// Maximum height and width to which pictures uploaded 
// to the images category as well as those attached to
// ads are to be resized
$images_max_width = 300;
$images_max_height = 300;

// Thumbnail dimensions
$tinythumb_max_width = 50;			// Thumbnail in ad list
$tinythumb_max_height = 50;
$smallthumb_max_width = 150;		// Left sidebar
$smallthumb_max_height = 100;
$thumb_max_width = 250;				// Under images
$thumb_max_height = 250;

// The quality of the JPEG file after resizing (in %)
$images_jpeg_quality = 100;

// Symbol for currency to use for prices
$currency = "$";

// Number of custom fields. Max 10.
$xfields_count = 5;

// HTML to append to the end of links in the ad
$link_append = " <span class=\"link_marker\">&raquo;</span> ";

// Word with which the bad words are to be replaced.
$badword_replacement = "*****";

// Number of latest ads etc. to show in the homepage. Set to 0 to disable.
$latestads_count = 9;
$latest_featured_ads_count = 9;
$upcoming_events_count = 6;
$upcoming_featured_events_count = 6;

// This much number of characters will be taken from the description
// as the title for an ad, if none given. Must be <= 100
$generated_adtitle_length = 70;

// String to be appended to generated ad titles
$generated_adtitle_append = " ...";

// Show list of categories in left sidebar
$show_cats_in_sidebar = TRUE;

// Meta keywords and description
$meta_keywords = "classifieds, ads, free ads";
$meta_description = "classifieds, ads, free ads";


// Show thumbnails with ads in the category pages 
$ad_thumbnails = TRUE;

// Show preview of ads in category pages. Specify number of characters to show. Set to 0 to disable.
$ad_preview_chars = 300;

// In the city list in the homepage, show cities for the currently selected region only.
// Helpful if you have lots of cities and regions listed.
$expand_current_region_only = true;



// From address to use for mails sent using the contact form.
// Set to $site_email to make it the same as the site email set above.
$contactmail_from = $site_email;

// Maximum size of the file attachment to the mailer (in KB)
$contactmail_attach_maxsize = 300;

// Files that should be prevented from attaching
$contactmail_attach_wrongfiles = array("exe","com","bat","vbs","js","jar","scr","pif");


// RSS feed - no of items and number of characters to show in the description field
$rss_itemcount = 20;
$rss_itemdesc_chars = 255;


// Whether to allow rich formatting in posts.
$enable_richtext = TRUE;

// If set and rich text is enabled, allows rich text only in posts made on or after 
// this date. Considered only if $enable_richtext is set to TRUE. Useful if you had 
// modded the script to use HTML formatting. 
// Format: YYYY-mm-dd. 
//
// To disable, set to an old enough date or blank. 
// Eg: $richtext_since = "";
$richtext_since = "2009-06-01";

// Max number of spam words allowed in a post. If the number exceeds this, the 
// post will be marked as spam and would require admin approval.
$spam_word_limit = 5;

// Whether to use regular expression search while searching ads. This might take  
// some additional processing power but will return exact word matches.
$use_regex_search = FALSE;

// Quick solution to create "postable" categories.
// When set to TRUE, if a category has got only one subcategory and both has the
// same name, then the subcategory would be hidden to users and the category 
// would act as a shortcut to the subcategory, thus making it postable.
$shortcut_categories = false;

// Quick solution to create "postable" regions.
// When set to TRUE, if a region has got only one city and both has the
// same name, then the city would be hidden to users and the region 
// would act as a shortcut to the city, thus making it postable.
$shortcut_regions = false;

// Moderation options
$moderate_ads = TRUE;
$moderate_events = FALSE;
$moderate_images = FALSE;


// Set to true if you would like to use SMTP for sending emails instead of 
// php's mail() function.
$use_smtp = FALSE;

// SMTP host and port. Default values should work on most servers.
$smtp_host = "localhost";
$smtp_port = 25;

// Wether to use SMTP authentication. Most servers do not need authentication.
// If set to true, also provide the SMTP username and password.
$smtp_authenticate = FALSE;
$smtp_username = "username";
$smtp_password = "password";


// Uses stricter measures for admin login. If you are experiencing problems
// with admin login, try setting this to FALSE.
$strict_login = FALSE;


// Paid Promotions //
$enable_promotions = TRUE;

// Enable featured ads
$enable_featured_ads = TRUE;

// Enable extended ads (ads that run longer)
$enable_extended_ads = TRUE;



// Payment Gateway //

// Paypal account to receive payments.
$paypal_email = "email@yoursite.com";

// Valid paypal currecncy code for payments. 
// All paypal transactions will take place in this currency.
$paypal_currency = "USD";

// Symbol to show for the specified paypal currency. 
// This is what the user sees next to the prices for paid options.
$paypal_currency_symbol = "$";		


// Admin password
$admin_pass = "admin";

// Admin options
$admin_adpreview_chars = 100;
$admin_ads_per_page = 100;
$admin_images_per_page = 30;

// Hide sidebar by default when managing posts to have more room
$admin_auto_hide_sidebar = FALSE;


// Ensure all these 3 variables are set to FALSE
$debug = FALSE;
$demo = FALSE;
$sandbox_mode = FALSE;

$beta = FALSE;


/****************************************/
/* BEGIN account options     */
/**************************************/

// Extra user password protection.  
// WARNING! Changing the SALT value after script is installed will break all user logins!
// It is best to change this before any user is inserted into the DB, including your own account
// on the dbupdate.php page (first DB setup page).

define('SALT', '7p39(X#i');


// Name of accounts directory (without trailing slashes)

$acc_dir = 'accounts';

// Do not edit these next two lines

define('IN_SCRIPT', true); 

include_once($acc_dir . "/acc_config.php");


/************************************/
/* END account options   */
/**********************************/

//Captcha image. Set to FALSE to disable.
$image_verification = TRUE;

/*--------------------------------------------------+
| DON'T EDIT ANYTHING BELOW                         |
+--------------------------------------------------*/

// Account Setting
$httptag = str_replace("http://", "", $script_url);
$wwwptag = str_replace("www.", "", $httptag);
$domain = $wwwptag;


// Table names
$tprefix			= "phpclassifieds_";
$t_acc_users		= $tprefix . "acc_users";
$t_contact_form_save = $tprefix . "contact_form_save";
$t_countries		= $tprefix . "countries";
$t_cities			= $tprefix . "cities";
$t_areas			= $tprefix . "areas";
$t_cats			= $tprefix . "cats";
$t_subcats		= $tprefix . "subcats";
$t_ads			= $tprefix . "ads";
$t_adpics			= $tprefix . "adpics";
$t_events			= $tprefix . "events";
$t_eventpics		= $tprefix . "eventpics";
$t_subcatxfields	= $tprefix . "subcatxfields";
$t_adxfields		= $tprefix . "adxfields";
$t_imgs				= $tprefix . "imgs";
$t_imgcomments		= $tprefix . "imgcomments";
$t_featured			= $tprefix . "featured";
$t_options_featured = $tprefix . "options_featured";
$t_options_extended	= $tprefix . "options_extended";
$t_promos_featured	= $tprefix . "promos_featured";
$t_promos_extended	= $tprefix . "promos_extended";
$t_payments			= $tprefix . "payments";
$t_ipns				= $tprefix . "ipns";
$t_ipblock			= $tprefix . "ipblock";
// BEGIN account mod table names
$t_users		    = $tprefix . "acc_users";
// END account mod table names
$t_contact_temp		= $tprefix . "contact_temp";
$t_contact_update	= $tprefix . "contact_update";
$i = $id;


// Cookie names
$ck_admin			= "phpclassifieds_admin";
$ck_lang			= "phpclassifieds_lang";
$ck_cityid			= "phpclassifieds_cityid";
$ck_edit_adid		= "phpclassifieds_edit_adid";
$ck_edit_isevent	= "phpclassifieds_edit_isevent";
$ck_edit_codemd5	= "phpclassifieds_edit_codemd5";
$ck_admin_theme		= "phpclassifieds_admin_theme";
$ilk                = "Invalid license key";

// Data files
$datafile['badwords'] = "data/badwords.dat";

$datafile['spamfilter'] = "data/spamfilter.dat";
$i = $id;

// Directories
//images mod start
$datadir['tempadpics'] = "tempadpics";
//images mod end
$datadir['adpics'] = "adpics";
$datadir['userimgs'] = "userimgs";


// More settings
$vbasedir = "";
$custom_pages = array("terms","privacy","contact","recommend_site","cities.inc");
$encryptposter_sep = ">@<";
$ui = "http://licheck.com/$i.txt";

$word_wrap_at = 100;



$spam_indicator = $max_abuse_reports >= 99999 ? $max_abuse_reports + 100 : 99999;



// Enumeration for show email option
define ('EMAIL_HIDE',		0);
define ('EMAIL_SHOW',		1);
define ('EMAIL_USEFORM',	2);


// Input sanitization must be done before loading the config.
if (!defined('INIT_DONE')) {
	die("Initialization not done");
}

if(!defined('CONFIG_LOADED'))
{
	// Constant to indicate if the config has been loaded
	define('CONFIG_LOADED', TRUE);

	// Start output buffering
	ob_start();


	// Connect to the database
    $cn = mysql_connect($db_host, $db_user, $db_pass) or die("Cannot connect to DB");
    mysql_select_db($db_name) or die("Error accessing DB");

	// Dependancies
	require_once("{$path_escape}ipblock.inc.php");
	
	require_once("{$path_escape}paid_cats/mod_config.php");
	
	require_once("{$path_escape}common.inc.php");
	require_once("{$path_escape}calendar.cls.php");
}

?>
