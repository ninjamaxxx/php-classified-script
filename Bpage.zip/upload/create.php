<?php

   $license = rand(1000, 9999)."-".rand(1000, 9999)."-".rand(1000, 9999)."-".rand(1000, 9999);
   
$myFile = $ourFileName = rand(1000000, 9000000).".txt";
$fh = fopen($myFile, 'w');

$stringData =  $license ;
fwrite($fh, $stringData);

fclose($fh);
   
   
   
   ?>