

<table width="100%" id="footer" bgcolor="white" style="border-radius: 5px;-moz-border-radius: 5px;">
<tr><td>
<center>
Copyright &copy; 2010 <?php echo $site_name; ?>. All Rights Reserved | Powered by <a href="http://www.php-classifieds.com">PHP Classifieds</a> | 
<a href="index.php?view=page&pagename=terms"><?php echo $lang['TERMS_OF_USE']; ?></a> | 
<a href="index.php?view=page&pagename=privacy"><?php echo $lang['PRIVACY_POLICY']; ?></a> | <a href="index.php?view=page&pagename=recommend_site"><?php echo $lang['RECOMMEND_SITE']; ?></a><br>
</center>
<br>
</td></tr>

<?php if ($xview == "main") { ?>

<tr>
<td width="100%" height="20" class="footer1" valign="middle" style="border-radius: 5px;-moz-border-radius: 5px;"><center>
Copyright <?php echo $site_name; ?> 2012 | About  | Terms Of Use | Contact Us | Sponsored Links | Featured Ads | How to Partner with us | Browse Cities | Sitemap | etc
</center><br />
</td></tr><tr>
<td width="100%" height="47" class="footerbottom" style="border-radius: 5px;-moz-border-radius: 5px;">
<?php echo $xcityid>0 && !$postable_country?"Location: "."$xcityname, $xcountryname":$xcountryname; ?>
<br />
 <?php echo $xcityid>0 && !$postable_country?"Free classifieds in:"."$xcityname, $xcountryname":$xcountryname; ?>

</td>
</tr>
<br />
<?PHP } 

else {

?>

<tr>
<td width="100%" style="border-bottom: 1px solid gray;">
&nbsp;
</td>
</tr>


<?php } ?>

</table>
