<?PHP

function printStat($sql) {
	list($stat) = mysql_fetch_row(mysql_query($sql));
	$stat += 0;
	echo number_format($stat);
}

?>


<br />


