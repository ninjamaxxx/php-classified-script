<?php

require_once("initvars.inc.php");
require_once("config.inc.php");



if($offline == "yes") 
{ 
echo" 
<div align=\"center\"> 
  <center> 
Our website is currently offline. Please visit us back again later. 
  </center> 
</div> 
"; 
exit(); 
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html lang="<?php echo $langx['lang']; ?>">

<head>
<title><?php echo $page_title; ?></title>
<base href="<?php echo $script_url; ?>/">
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $langx['charset']; ?>">
<meta name="keywords" content="<?php echo $meta_keywords; ?>">
<meta name="description" content="<?php echo $meta_description; ?>">
<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="pager.css">
<link rel="stylesheet" type="text/css" href="cal.css">

<link rel="alternate" type="application/rss+xml" title="<?php echo rssTitle("", ""); ?>" 
	href="<?php echo "{$script_url}/{$global_rssurl}"; ?>">
<?php if (!empty($rssurl)) { ?>
<link rel="alternate" type="application/rss+xml" title="<?php echo rssTitle(($xsubcatname?$xsubcatname:$xcatname), ($xcityname?$xcityname:"")); ?>" 
	href="<?php echo "{$script_url}/{$rssurl}"; ?>">
<?php } ?>


<script src="jquery.tools.min.js"></script>


<?php
if($xview == "ads") { 
?>  

<script type="text/javascript" src="bookmarkAds.js"></script>


<?php
}
?>



<!-- clear input on focus starts here. just add onFocus="clearText(this)"-->
<script>


function clearText(thefield){
if (thefield.defaultValue==thefield.value)
thefield.value = ""
} 
</script>
<!-- clear input on focus ends here -->


<?php

if ($xview == "selectcity") {

?>

<!-- ajax cat loader starts here -->

<script type="text/javascript">

var bustcachevar=1 //bust potential caching of external pages after initial request? (1=yes, 0=no)
var loadedobjects=""
var rootdomain="http://"+window.location.hostname
var bustcacheparameter=""

function ajaxpage(url, containerid){
var page_request = false
if (window.XMLHttpRequest) // if Mozilla, Safari etc
page_request = new XMLHttpRequest()
else if (window.ActiveXObject){ // if IE
try {
page_request = new ActiveXObject("Msxml2.XMLHTTP")
} 
catch (e){
try{
page_request = new ActiveXObject("Microsoft.XMLHTTP")
}
catch (e){}
}
}
else
return false
page_request.onreadystatechange=function(){
loadpage(page_request, containerid)
}
if (bustcachevar) //if bust caching of external page
bustcacheparameter=(url.indexOf("?")!=-1)? "&"+new Date().getTime() : "?"+new Date().getTime()
page_request.open('GET', url+bustcacheparameter, true)
page_request.send(null)
}

function loadpage(page_request, containerid){
if (page_request.readyState == 4 && (page_request.status==200 || window.location.href.indexOf("http")==-1))
document.getElementById(containerid).innerHTML=page_request.responseText
}

function loadobjs(){
if (!document.getElementById)
return
for (i=0; i<arguments.length; i++){
var file=arguments[i]
var fileref=""
if (loadedobjects.indexOf(file)==-1){ //Check to see if this object has not already been added to page before proceeding
if (file.indexOf(".js")!=-1){ //If object is a js file
fileref=document.createElement('script')
fileref.setAttribute("type","text/javascript");
fileref.setAttribute("src", file);
}
else if (file.indexOf(".css")!=-1){ //If object is a css file
fileref=document.createElement("link")
fileref.setAttribute("rel", "stylesheet");
fileref.setAttribute("type", "text/css");
fileref.setAttribute("href", file);
}
}
if (fileref!=""){
document.getElementsByTagName("head").item(0).appendChild(fileref)
loadedobjects+=file+" " //Remember this object as being already added to page
}
}
}

</script>

<!-- ajax cat loader ends here -->


<script type="text/javascript">
var whosChanged = null;
function changeMe(el)
{
el.style.backgroundColor = "PaleGreen";
el.style.color = "#000000";
el.style.fontSize ="10px";
if (whosChanged != null)
{
whosChanged.style.backgroundColor = "#FFEFD5"
whosChanged.style.color = ""
whosChanged.style.fontSize ="12px";
}
whosChanged = el;
}


var whosChanged2 = null;
function changeMe2(el)
{
el.style.backgroundColor = "PaleGreen";
el.style.color = "#000000";
el.style.fontSize ="12px";
if (whosChanged2 != null)
{
whosChanged2.style.backgroundColor = "#FFEFD5"
whosChanged2.style.color = ""
whosChanged2.style.fontSize ="12px";
}
whosChanged2 = el;
}


var whosChanged3 = null;
function changeMe3(el)
{
el.style.backgroundColor = "PaleGreen";
el.style.color = "#000000";
el.style.fontSize ="12px";
if (whosChanged2 != null)
{
whosChanged3.style.backgroundColor = "#FFEFD5"
whosChanged3.style.color = ""
whosChanged3.style.fontSize ="12px";
}
whosChanged3 = el;
}


</script>


<?php

}

?>



</head>

<?php

if ($xview == "showad" OR $xview == "showevent") {

?>

<body onload="load()" onunload="GUnload()" >

<?php

}

else {

?>

<body>

<?php

}

?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr><td>


<table width="836px" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="white" >

	<tr><td colspan="3"><?php include("header.inc.php"); ?>
</td></tr>	
	
	<tr>


		<?php
		if ($xview == "main" || $show_sidebar_always)
		{
		?>


		<td width="185" id="sidebar_left" valign="top">

<center>		<H1><?php echo $site_name; ?></H1><br/>
			<!-- Begin Version 
			<a href="index.php?cityid=0"><?php //echo $lang['HOME_LINK']; ?></a>
		 -->
			<a href="<?php echo $postlink; ?>"><?php echo $lang['POST_LINK']; ?></a><br />
			<a href="account.html"><?php echo $lang['ACCOUNT_LINK']; ?></a><br />
			<a href="bookmarkstotal.html">Bookmarks</a><br />
			
			<?php if($enable_calendar) { ?>
			<a href="<?php echo $posteventlink; ?>"><?php echo $lang['POST_EVENT_LINK']; ?></a><br >
		
			
			<?php } ?>

			<?php if($enable_images) { ?>
		
			<a href="<?php echo $postimagelink; ?>"><?php echo $lang['POST_IMG_LINK']; ?></a>
		
			<?php } ?>


		
</center>
			<br>



			<?php
			if($xview != "post" && $xview != "postimg")
			{
			?>

			<table width="90%" class="sidebox" cellspacing="0" align="center">
				<tr><th class="head">
				<?php echo $lang['SEARCH']; ?>
				</tr></th>
				<tr><td>
				<?php include("search.inc.php"); ?>
				</td></tr>
				<tr><td>&nbsp;</td></tr>
			</table><br>

			<?php
			}
			?>



			<?php if($show_cats_in_sidebar && !($xview == "main" || $xpostmode)) { ?>
				<table width="90%" class="sidebox" cellspacing="0" align="center">
				<tr><th class="head"><?php echo $lang['CATEGORIES']; ?></th></tr>
				<tr><td><?php include("cats.inc.php"); ?></td></tr>
				</table><br>
			<?php } ?>



			<?php
			if ($enable_calendar && !$xpostmode)
			{ 
			?>

				<table width="90%" cellspacing="0" class="sidebox" align="center">
					<?php
					$sql = "SELECT COUNT(*)
							FROM $t_events a
								INNER JOIN $t_cities ct ON a.cityid = ct.cityid
							WHERE $visibility_condn
								$loc_condn";
					list($eventcount) = @mysql_fetch_array(mysql_query($sql));
					$eventcount = 0+$eventcount;
					?>
					<tr><th class="head"><?php echo $lang['EVENT_CALENDAR']; ?> (<?php echo $eventcount; ?>)</th></tr>
					
					<tr><td>
					<br>
					<?php
					/* Begin Version 5.0 */
					$url = buildURL("events", array($xcityid, "{@Y}-{@M}-{@D}"));
					/* End Version 5.0 */
					echo calendar::display($url, $langx['firstweekday'], $langx['weekdays'], $langx['months'], $_GET['_xzcal_y'], $_GET['_xzcal_m'], $specialdates);
					?>
					<br>
					</td></tr>

					<tr><td align="center">
					<?php
					$date = date("Y-m-d");
					$sql = "SELECT COUNT(*)
							FROM $t_events a
								INNER JOIN $t_cities ct ON a.cityid = ct.cityid
							WHERE starton <= '$date' AND endon >= '$date'
								AND $visibility_condn
								$loc_condn";

					list($eventstoday) = @mysql_fetch_array(mysql_query($sql));
					$eventstoday = 0+$eventstoday;
					?>
					<div align="center">
					<?php
					$today = date("Y-m-d");
					/* Begin Version 5.0 */
					$events_url = buildURL("events", array($xcityid, $today));
					$upcoming_events_url = buildURL("events", array($xcityid));
					/* End Version 5.0 */

					?>
					<b>
					
					<a href="<?php echo $events_url; ?>"><?php echo $eventstoday; ?> <?php echo $lang['X_EVENTS_TODAY']; ?></a><br>
					<a href="<?php echo $upcoming_events_url; ?>">All Upcoming Events</a><br><br>
					<a href="<?php echo $posteventlink; ?>"><?php echo $lang['POST_EVENT_LINK']; ?></a>

					</b>
					</div>
					</td></tr>

				</table><br><br>

			<?php
			}
			?>

			<?php
			if ($enable_images && ($xview == "main" || $xsection == "imgs"))
			{
				$sql = "SELECT COUNT(*) as imgcnt
						FROM $t_imgs a
							INNER JOIN $t_cities ct ON a.cityid = ct.cityid
						WHERE $visibility_condn AND ct.enabled = '1'
							$loc_condn_img";
				list($imgcnt) = @mysql_fetch_array(mysql_query($sql));

			?>

				<table width="90%" cellspacing="0" class="sidebox" align="center">
				<tr><th class="head"><?php echo $lang['IMAGES']; ?> (<?php echo $imgcnt; ?>)</th></tr>

				<tr><td>

				<div align="center">
				<?php
				$rand = rand(0, $imgcnt-1);
				$sql = "SELECT a.*, UNIX_TIMESTAMP(a.createdon) AS createdon 
						FROM $t_imgs a 
							INNER JOIN $t_cities ct ON a.cityid = ct.cityid 
						WHERE $visibility_condn
							$loc_condn_img 
						LIMIT $rand, 1";
				$img = @mysql_fetch_array(mysql_query($sql));

				if ($img)
				{
				
					$posterenc = EncryptPoster("IMG", $img['postername'], $img['posteremail']);
					/* Begin Version 5.0 */
					$imgurl = buildURL("showimg", array($xcityid, $posterenc, $img['imgid']));
					$allimgurl = buildURL("imgs", array($xcityid));
					/* End Version 5.0 */

					$imgsize = GetThumbnailSize("{$datadir[userimgs]}/{$img[imgfilename]}", $smallthumb_max_width, $smallthumb_max_height);
			
				?>
					<br>
					<a href="<?php echo $imgurl; ?>">
					<img src="<?php echo "{$datadir[userimgs]}/{$img[imgfilename]}"; ?>" border="0" class="thumb" id="latestimg" width="<?php echo $imgsize[0]; ?>" height="<?php echo $imgsize[1]; ?>"></a><br>
					<br>
					<b><?php echo $img['imgtitle']; ?></b><br>
					<?php echo $lang['POSTED_BY']; ?> <b><?php echo $img['postername']; ?></b>
					<br>

				<?php
				}
				?>

				<br>
				<b><a href="<?php echo $allimgurl; ?>"><?php echo $lang['ALL_IMAGES']; ?></a></b>
				<br>
				<b><a href="?view=postimg&cityid=<?php echo $xcityid; ?>&lang=<?php echo $xlang; ?>"><?php echo $lang['POST_IMG_LINK']; ?></a></b>

				</div>
				</td></tr>
				</table>

			<?php
			}
			?>
			<br>


			<table width="90%" cellspacing="0" class="sidebox" align="center"><tr><td align="left">
			<?php include("sidebar_left.inc.php"); ?>
			</td></tr></table>
			<br>


		</td>




		<?php
		} 
		?>


		<td valign="top" id="contentcell" >




     
        
		<table width="100%" cellspacing="0" cellpadding="0" bgcolor="white">
		<tr>
		<td id="content">
 <?php include("path.inc.php"); ?>
		<?php

        $page = "main.php";
		switch($xview)
		{
			case "subcats"		: $page = "subcats.php";			break;
		
			case "login"	    : $page = $acc_dir . "/login.php";	         break;
			case "userpanel"    : $page = $acc_dir . "/user_panel.php";	 break;
			case "signup"	    : $page = $acc_dir . "/signup.php";		 break;
			case "forgot"	    : $page = $acc_dir . "/forgot.php";		 break;
		
			
			case "ads"		: $page = "ads.php";				break; 
			case "events"		: $page = "ads.php";				break;
			case "showad"		: $page = "showad.php";				break;
			case "showevent"	              : $page = "showad.php";				break;
			case "post"		: $page = "post.php";				break;
			case "spec"		: $page = "spec.php";			              break;
			case "edit"		: $page = "edit.php";		              	break;
			case "renew"		: $page = "renew.php";				break;
			case "imgs"		: $page = "imgs.php";				break;
			case "showimg"		: $page = "showimg.php";				break;
			case "postimg"		: $page = "postimg.php";				break;
			case "widget"		: $page = "widget.php";				break;
			case "editimg"		: $page = "editimg.php";				break;
			case "activate"		: $page = "activate.php";				break;
			case "selectcity"		: $page = "selectcity.php";				break;
			case "mailad"		: $page = "mailad.php";				break;
			/*bookmark mod start*/
			case "bookmarkstotal"	: $page = "bookmarkstotal.php";	break;
			/*bookmark mod end*/
			
			
	
			case "post404"		: $page = "post404.php";				break;
			
			case "page"			: if (isCustomPage($_GET['pagename'])) { $page = "$_GET[pagename].php"; }	break;
		}

		include_once($page);

		?>

		</td>
		</tr></table>






		</td>

<?php if($xview == "main") { ?>
    <td width="150" valign="top" id="sidebar_right_cities"><?php include("cities.inc.php"); ?></td>
	
			</td>	

		<?php } 

elseif($show_right_sidebar) { ?>

			<td width="150" valign="top" id="sidebar_right" bgcolor="white">

			<?php include("sidebar_right.inc.php"); ?>

			</td>

		<?php } ?>
		

	</tr>







<tr><td colspan="3"><?php include("footer.inc.php"); 


?>



</td></tr>


</table>


</td></tr>
</table>



</body>
</html>