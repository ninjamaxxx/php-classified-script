<?php
require_once("initvars.inc.php");
require_once("config.inc.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-us">
	<head>
	  <title><?php echo $page_title; ?></title>
	<base href="<?php echo $script_url; ?>/" />
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $langx['charset']; ?>" />
	<meta name="keywords" content="<?php echo $meta_keywords; ?>" />
	<meta name="description" content="<?php echo $meta_description; ?>" />
      <link rel="stylesheet" type="text/css" href="css/Standard.css" />
	  
	  
<?php
if($xview == "ads") { 
?>  

<script type="text/javascript" src="bookmarkAds.js"></script>


<?php
}
?>



<!-- clear input on focus starts here. just add onFocus="clearText(this)"-->
<script>


function clearText(thefield){
if (thefield.defaultValue==thefield.value)
thefield.value = ""
} 
</script>
<!-- clear input on focus ends here -->

    </head>

    <body id="index">
    <div id="tlHeader">
      <div id="logo"><a href="<?php echo $homeurl; ?>" style="background-image: url(&quot;http://gogorover.com/images/logo.png&quot;);">gogorover.com</a></div>
<?php
$cityurl = buildURL("main", array($xcityid, $xcityname));
?>


	  <div id="community">
          <h1><span class="city"><?php echo $xcityid>0 && !$postable_country?"$xcityname, $xcountryname":$xcountryname; ?></span>&nbsp;<span class="comm">free&nbsp;classifieds</span></h1>
      </div><!-- #community -->
<!-- HERE!!!-->




        <div id="postAdButton">
          <a href="<?php echo $postlink; ?>"><?php echo $lang['POST_LINK']; ?></a>
        </div><!-- #postAdButton -->

        
          <div id="searchForms">

		  <?php include("welcome.inc.php"); ?>
		  
          </div><!-- #searchForms -->
        

          
        
      
    </div><!-- #tlHeader -->
  

  <div id="pageBackground" style="clear:both;">

  
    <div id="indexCommunitiesCell">
      <script type="text/javascript">
<!--   
  function show_divs_for_selected_in(obj) {
    var myOpts = obj.options;
    for (var i = 0; i < myOpts.length; i++ ) {
      var thisDiv = myOpts[i].value + "";
      var myDiv = document.getElementById(thisDiv);
      if (myDiv) { // could be null because of a few non-selectable options

        if (myOpts[i].selected) {
          myDiv.style.display="block";
         }
         else {
           myDiv.style.display="none";
         }
       }
    }
    return true;
  }
  
  function toggle_visibility(id) {
    var myId = document.getElementById(id);
    
    if (myId.style.display == "none") {
      myId.style.display = "block";
    }
    else {
      myId.style.display ="none";
    }
    return true;
  }
-->
</script>





  <!-- Site List Local -->
  <div class="communityHeader" id="bpSites" style="padding:0px 0 6px;font-style:normal;">
<div class="ol16">

<?php
//this file created for citiesdropdown mod only
require_once("initvars.inc.php");
require_once("config.inc.php");
$location_cols4=1;
$expand_current_region_only_THIS = FALSE;
?>
<SCRIPT LANGUAGE="JavaScript">
function formHandler(form){
var URL = document.form.site.options[document.form.site.selectedIndex].value;
window.location.href = URL;
}
</SCRIPT>
<form name="form">Change Your Location : 
<select size="1" name="site" onChange="javascript:formHandler()" style="font-family: Verdana; font-size:10px">
    <option>Click and change your location</option>
<?php

// Show city list

if($location_sort) 
{
	$sort1 = "ORDER BY countryname";
	$sort2 = "ORDER BY cityname";
}
else
{
	$sort1 = "ORDER BY c.pos";
	$sort2 = "ORDER BY ct.pos";
}

if ($show_region_adcount || $show_city_adcount)
{
	// First get ads per city and country
	$country_adcounts = array();
	$city_adcounts = array();
	$sql = "SELECT ct.cityid, c.countryid, COUNT(*) as adcnt
			FROM $t_ads a
				INNER JOIN $t_cities ct ON ct.cityid = a.cityid AND ($visibility_condn)
				INNER JOIN $t_countries c ON ct.countryid = c.countryid
			WHERE ct.enabled = '1' AND c.enabled = '1'
			GROUP BY ct.cityid";

	$res = mysql_query($sql) or die(mysql_error().$sql);

	while($row=mysql_fetch_array($res))
	{
		$country_adcounts[$row['countryid']] += $row['adcnt'];
		$city_adcounts[$row['cityid']] += $row['adcnt'];
	}
}

$sql = "SELECT * FROM $t_countries c INNER JOIN $t_cities ct ON c.countryid = ct.countryid AND ct.enabled = '1' WHERE c.enabled = '1' GROUP BY c.countryid $sort1";
$resc = mysql_query($sql);

$country_count = mysql_num_rows($resc);
//$split_at = ($country_count%3?((int)($country_count/3))+2:($country_count/3)+1);
$percol = floor($country_count/$location_cols4);
$percolA = array();
for($i=1;$i<=$location_cols4;$i++) $percolA[$i]=$percol+($i<=$country_count%$location_cols4?1:0);

$i = 0; $j = 0;
$col = 1;
while($country = mysql_fetch_array($resc))
{
	if($sef_urls) $country_url = "{$vbasedir}-$country[countryid]-" . RemoveBadURLChars($country['countryname']) . "/";
	else $country_url = "?cityid=-$country[countryid]&lang=$xlang";

?>


	<option value="<?php echo $script_url; ?>/<?php echo $country_url; ?>" style="font-weight: bold; font-size: 13px; color: blue;"><?php echo $country['countryname']; ?></option>


	<?php

	if($country['countryid'] == $xcountryid || !$expand_current_region_only_THIS)
	{

		$sql = "SELECT * FROM $t_cities ct WHERE countryid = $country[countryid] AND enabled = '1' $sort2";
		$resct = mysql_query($sql);

		while($city=mysql_fetch_array($resct))
		{
			if($sef_urls) $city_url = "{$vbasedir}$city[cityid]-" . RemoveBadURLChars($city['cityname']) . "/";
			else $city_url = "?cityid=$city[cityid]&lang=$xlang";

	?>

			<option value="<?php echo $script_url; ?>/<?php echo $city_url; ?>">&nbsp;&nbsp;&#8976;&nbsp;<?php echo $city['cityname']; ?></option>
			
	<?php

		}
	}

	?>


	<?php

	$i++; $j++;
}

?>

    </select>
</form>
</div>


  </div>

  
      
    
    
        
      
      <div class="communitylist">

		
	<?php	// Show city list

if($location_sort) 
{
	$sort1 = "ORDER BY countryname";
	$sort2 = "ORDER BY cityname";
}
else
{
	$sort1 = "ORDER BY c.pos";
	$sort2 = "ORDER BY ct.pos";
}

if ($show_region_adcount || $show_city_adcount)
{
	// First get ads per city and country
	$country_adcounts = array();
	$city_adcounts = array();
	$sql = "SELECT ct.cityid, c.countryid, COUNT(*) as adcnt
			FROM $t_ads a
				INNER JOIN $t_cities ct ON ct.cityid = a.cityid AND ($visibility_condn)
				INNER JOIN $t_countries c ON ct.countryid = c.countryid
			WHERE ct.enabled = '1' AND c.enabled = '1'
			GROUP BY ct.cityid";

	$res = mysql_query($sql) or die(mysql_error().$sql);

	while($row=mysql_fetch_array($res))
	{
		$country_adcounts[$row['countryid']] += $row['adcnt'];
		$city_adcounts[$row['cityid']] += $row['adcnt'];
	}
		/* Begin Version 2.1.1 - Include event count in total ad count */
	$sql = "SELECT ct.cityid, c.countryid, COUNT(*) as adcnt
				FROM $t_events a
					INNER JOIN $t_cities ct ON ct.cityid = a.cityid AND ($visibility_condn)
					INNER JOIN $t_countries c ON ct.countryid = c.countryid
				WHERE ct.enabled = '1' AND c.enabled = '1'
				GROUP BY ct.cityid";
	$res = mysql_query($sql) or die(mysql_error().$sql);
	
	while($row=mysql_fetch_array($res))
	{
		$country_adcounts[$row['countryid']] += $row['adcnt'];
		$city_adcounts[$row['cityid']] += $row['adcnt'];
	}
	/* End Version 2.1.1 - Include event count in total ad count */
}

$sql = "SELECT * FROM $t_countries c INNER JOIN $t_cities ct ON c.countryid = ct.countryid AND ct.enabled = '1' WHERE c.enabled = '1' GROUP BY c.countryid $sort1";
$resc = mysql_query($sql);

$country_count = mysql_num_rows($resc);
//$split_at = ($country_count%3?((int)($country_count/3))+2:($country_count/3)+1);
$percol = floor($country_count/$location_cols);
$percolA = array();
for($i=1;$i<=$location_cols;$i++) $percolA[$i]=$percol+($i<=$country_count%$location_cols?1:0);

$i = 0; $j = 0;
$col = 1;
while($country = mysql_fetch_array($resc))
{
    /* Begin Version 2.1 */
    $country_url = buildURL("main", array((0-$country['countryid']), $country['countryname']));
    /* End Version 2.1 */
?>


  <div class="communityHeader" id="top_20_header" style="padding:0px 0 6px;font-style:normal;display:block;">
      Categories:
    </div>



	<?php

	if($country['countryid'] == $xcountryid || !$expand_current_region_only)
	{

		$sql = "SELECT * FROM $t_cities ct WHERE countryid = $country[countryid] AND enabled = '1' $sort2";
		$resct = mysql_query($sql);
        
        /* Begin Version 2.1 */
        $citycount = mysql_num_rows($resct);
        /* End Version 2.1 */

		while($city=mysql_fetch_array($resct))
		{        
		    /* Begin Version 2.1 */
    	    if ($shortcut_regions && $citycount == 1 
    	            && $city['cityname'] == $country['countryname']) {
    	        continue;
    	    }
    	    
    	    $city_url = buildURL("main", array($city['cityid'], $city['cityname']));
    	    /* End Version 2.1 */

	?>

			<span style="padding-left:5px;"><a href="<?php echo $city_url; ?>"><?php echo $city['cityname']; ?> </a></span><br>
			
	<?php

		}
	}

	?>


	<?php

	$i++; $j++;
	//if($i%$split_at == 0) echo "</td><td valign=\"top\">";
	if ($j%$percolA[$col]==0 && $i<$country_count) { echo "</td><td valign=\"top\">"; $col++; $j=0; } 

}

?>
		
		
		
		
		
		
		
		
		
		
                  
      </div>
    

  
  <br>
  
  
  
    <div class="communityHeader" id="top_20_header" style="padding:0px 0 6px;font-style:normal;display:block;">
      Categories:
    </div>
    <div class="communitylist" id="top_20_list" style="padding:0px 0 6px;font-style:normal;display:block;">
<div class="catlist">
<?php

// List of categories

if($dir_sort) 
{
	$sortcatsql = "ORDER BY catname";
	$sortsubcatsql = "ORDER BY subcatname";
}
else
{
	$sortcatsql = "ORDER BY pos";
	$sortsubcatsql = "ORDER BY scat.pos";
}


// First get ads per cat and subcat
$subcatadcounts = array();
$catadcounts = array();
$sql = "SELECT scat.subcatid, scat.catid, COUNT(*) as adcnt
		FROM $t_ads a
			INNER JOIN $t_subcats scat ON scat.subcatid = a.subcatid AND ($visibility_condn)
			INNER JOIN $t_cats cat ON cat.catid = scat.catid
			INNER JOIN $t_cities ct ON a.cityid = ct.cityid
		WHERE scat.enabled = '1'
			$loc_condn
		GROUP BY a.subcatid";

$res = mysql_query($sql) or die(mysql_error().$sql);

while($row=mysql_fetch_array($res))
{
	$subcatadcounts[$row['subcatid']] = $row['adcnt'];
	$catadcounts[$row['catid']] += $row['adcnt'];
}



// Categories
$sql = "SELECT catid, catname AS catname FROM $t_cats WHERE enabled = '1' $sortcatsql";
$rescats = mysql_query($sql) or die(mysql_error());
$catcount = @mysql_num_rows($rescats);

$percol_short = floor($catcount/$dir_cols);
$percol_long = $percol_short+1;
$longcols = $catcount%$dir_cols;

$i = 0;
$j = 0;
$col = 0;
$thiscolcats = 0;

while($rowcat=mysql_fetch_array($rescats))
{
	if ($j >= $thiscolcats)
	{
		$col++;
		$thiscolcats = ($col > $longcols) ? $percol_short : $percol_long;
		$j = 0;
	}

	$i++;
	$j++;

   
    $catlink = buildURL("ads", array($xcityid, $rowcat['catid'], $rowcat['catname']));
    
    
	$adcount = 0+$catadcounts[$rowcat['catid']];

?>

	<div class="cat">
	<img src="images/bullet.gif" align="absmiddle"> <a href="<?php echo $catlink; ?>"><?php echo $rowcat['catname']; ?></a>
	<?php if($show_cat_adcount) { ?><span class="count">(<?php echo $adcount; ?>)</span><?php } ?>
	</div>

<?php

	if($xcatid == $rowcat['catid']) 
	{

		$sql = "SELECT scat.subcatid, scat.subcatname AS subcatname
		FROM $t_subcats scat
		WHERE scat.catid = $rowcat[catid]
			AND scat.enabled = '1'
		$sortsubcatsql";

		$ressubcats = mysql_query($sql) or die(mysql_error()."<br>$sql");
		
		
    	$subcatcount = mysql_num_rows($ressubcats);
    

		while ($rowsubcat = mysql_fetch_array($ressubcats))
		{
		    
    	    if ($shortcut_categories && $subcatcount == 1 
    	            && $rowsubcat['subcatname'] == $rowcat['catname']) {
    	        continue;
    	    }
    	    
	    
			$adcount = 0+$subcatadcounts[$rowsubcat['subcatid']];

			
			$subcat_url = buildURL("ads", array($xcityid, $rowcat['catid'], $rowcat['catname'], $rowsubcat['subcatid'], $rowsubcat['subcatname']));
			

?>

			<div class="subcat">
			&nbsp; &nbsp; <a href="<?php echo $subcat_url; ?>"><?php echo $rowsubcat['subcatname']; ?></a>
			<?php if($show_subcat_adcount) { ?><span class="count">(<?php echo $adcount; ?>)</span><?php } ?>
			</div>

<?php

		}
	}
}

?>
</div>

	  
	  
    </div>
  
  
  
  
  
    <div class="communityHeader" id="postMultiCities" style="padding:0px 0 6px;font-style:normal;">
      <!-- <a href="#">post in multiple cities</a>-->
    </div>
    </div><!-- #indexCommunitiesCell -->
    <div id="mainCellWrapper">
    
      <div id="mlInterface"><div class="multiToggle"><a href="#es-us" rel="nofollow" onclick="javascript:changePage('http://auburn.backpage.com/es-us/'); return false;">español</a></div></div>




  <!-- 2013-04-13 04:00:00 -->
  <table class="mainCellBackground" style="width: 100%;" id="columnsTable" border="0" cellpadding="0" cellspacing="0">

  
		<table width="100%" cellspacing="0" cellpadding="0" bgcolor="white">
		<tr>
		<td id="content">

		<?php

        $page = "main.php";
		switch($xview)
		{
			case "subcats"		: $page = "subcats.php";			break;
		
			case "login"	    : $page = $acc_dir . "/login.php";	         break;
			case "userpanel"    : $page = $acc_dir . "/user_panel.php";	 break;
			case "signup"	    : $page = $acc_dir . "/signup.php";		 break;
			case "forgot"	    : $page = $acc_dir . "/forgot.php";		 break;
		
			
			case "ads"		: $page = "ads.php";				break; 
			case "events"		: $page = "ads.php";				break;
			case "showad"		: $page = "showad.php";				break;
			case "showevent"	              : $page = "showad.php";				break;
			case "post"		: $page = "post.php";				break;
			case "spec"		: $page = "spec.php";			              break;
			case "edit"		: $page = "edit.php";		              	break;
			case "renew"		: $page = "renew.php";				break;
			case "imgs"		: $page = "imgs.php";				break;
			case "showimg"		: $page = "showimg.php";				break;
			case "postimg"		: $page = "postimg.php";				break;
			case "widget"		: $page = "widget.php";				break;
			case "editimg"		: $page = "editimg.php";				break;
			case "activate"		: $page = "activate.php";				break;
			case "selectcity"		: $page = "selectcity.php";				break;
			case "mailad"		: $page = "mailad.php";				break;
			/*bookmark mod start*/
			case "bookmarkstotal"	: $page = "bookmarkstotal.php";	break;
			/*bookmark mod end*/
			
			
	
			case "post404"		: $page = "post404.php";				break;
			
			case "page"			: if (isCustomPage($_GET['pagename'])) { $page = "$_GET[pagename].php"; }	break;
		}

		include_once($page);

		?>

		</td>
		</tr></table>


  
  
  
  
  
  </table>


</div>
    <!-- #mainCellWrapper -->
  
  
  


  <div id="tlFooter">
    <div class="footerText">
Copyright &copy; 2010 <?php echo $site_name; ?>. All Rights Reserved | Powered by <a href="http://www.php-classifieds.com">PHP Classifieds</a> | 
<a href="index.php?view=page&pagename=terms"><?php echo $lang['TERMS_OF_USE']; ?></a> | 
<a href="index.php?view=page&pagename=privacy"><?php echo $lang['PRIVACY_POLICY']; ?></a> | <a href="index.php?view=page&pagename=recommend_site"><?php echo $lang['RECOMMEND_SITE']; ?></a><br>
  </div><!-- #tlFooter -->

  </div><!-- #pageBackground -->
  
  

  
    
    

</body></html>
