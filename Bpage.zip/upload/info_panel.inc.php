

<div style="border:1px solid gray;width:728px;">

<img src="images/sample_banner.jpg">

<!-- Content goes above -->

</div>