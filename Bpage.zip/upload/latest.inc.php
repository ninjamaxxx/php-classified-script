<?php




require_once("initvars.inc.php");
require_once("config.inc.php");

?>
<?php
if($latestads_count)
{
?>


<div class="latestposts">

<div><font color="#4682B4"><?php echo $lang['LATEST_ADS']; ?></font></div>


<table border="0" cellspacing="0" cellpadding="0"  class="postlisting" width="100%">


<?php
	$sql = "SELECT a.*, ct.cityname, UNIX_TIMESTAMP(a.createdon) AS timestamp, feat.adid AS isfeat,
				COUNT(*) AS piccount, p.picfile AS picfile, scat.subcatname, scat.catid, cat.catname
			FROM $t_ads a
				INNER JOIN $t_cities ct ON a.cityid = ct.cityid
				INNER JOIN $t_subcats scat ON a.subcatid = scat.subcatid
				INNER JOIN $t_cats cat ON scat.catid = cat.catid
				LEFT OUTER JOIN $t_featured feat ON a.adid = feat.adid AND feat.adtype = 'A' AND feat.featuredtill >= NOW()
				LEFT OUTER JOIN $t_adpics p ON a.adid = p.adid AND p.isevent = '0'
			WHERE $visibility_condn
				
			GROUP BY a.adid
			ORDER BY a.createdon DESC
			LIMIT $latestads_count";
	$res_latest = mysql_query($sql) or die($sql.mysql_error());

	$css_first = "_first";
	while($row = mysql_fetch_array($res_latest))
	{
		/* Begin Version 5.0 */
		$url = buildURL("showad", array($xcityid, $row['catid'], $row['catname'], 
		    $row['subcatid'], $row['subcatname'], $row['adid'], $row['adtitle']));
		/* End Version 5.0 */

?>
	
		<?php 
		if($row['isfeat'])
		{
			//$feat_class = "class=\"featured\"";
			$feat_img = "<img src=\"images/featured.gif\" align=\"absmiddle\">";
		} 
		else 
		{ 
			//$feat_class = "";
			$feat_img = "";
		}

		if($row['picfile']) 
		{
			$picfile = $row['picfile'];
			$imgsize = GetThumbnailSize("{$datadir[adpics]}/{$picfile}", $tinythumb_max_width, $tinythumb_max_height);
		}
		else 
		{
			$picfile = "no_image.png";
                        $imgsize = GetThumbnailSize("{$datadir[adpics]}/{$picfile}", $tinythumb_max_width, $tinythumb_max_height);
		}
		?>

		<tr>
			<td width="15">
			<img src="images/bullet.gif" align="absmiddle">
			</td>
			
			<td onmouseover="style.backgroundColor='#FFE4B5';"
onmouseout="style.backgroundColor='white'">
			<a href="<?php echo $url; ?>" <?php echo $feat_class; ?>><?php echo $row['adtitle']; ?></a> 
			<?php if(0&&$row['picfile']) { ?><img src="images/adwithpic.gif" align="absmiddle"><?php } ?>
			<?php echo $feat_img; ?><br>


			<span class="adcat">
			
			
			
			<?php echo "$row[catname] $path_sep $row[subcatname]"; ?>
			
			<br>
			
			<?php 
			 echo $row['cityname'];
			?>			
			
			</span>

			
			
			</td>

			<td  align="right" width="<?php echo $tinythumb_max_width; ?>">
			<?php if($picfile) { ?>
			<a href="<?php echo $url; ?>"><img src="<?php echo "{$datadir[adpics]}/{$picfile}"; ?>" border="0" width="<?php echo $imgsize[0]; ?>" height="<?php echo $imgsize[1]; ?>" style="border:1px solid #87CEFA"></a>
			<?php } ?>
			</td>
			
		</tr>

<?php
		$css_first = "";
	}
?>

</table>
</div>

<?php
}
?>