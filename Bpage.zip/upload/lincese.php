<html>

<form method="post" action="register2.php">
  Username<br/><input type="text" name="username" maxlength="20" /><br/>
  Password<br/><input type="password" name="password" /><br/>
  Email<br/><input type="text" name="email" /><br/>
</form>
</html>
