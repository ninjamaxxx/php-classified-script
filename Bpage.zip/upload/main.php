<?php




require_once("initvars.inc.php");
require_once("config.inc.php");




?>


<center>






<table width="100%" cellspacing="0" cellpadding="0">


<tr></tr>

</table>



</center>




<table border="0" align="center" cellspacing="0" cellpadding="0" width="100%" class="dir"><tr>

<?php

// Create main directory

if($dir_sort) 
{
	$sortcatsql = "ORDER BY catname";
	$sortsubcatsql = "ORDER BY subcatname";
}
else
{
	$sortcatsql = "ORDER BY pos";
	$sortsubcatsql = "ORDER BY scat.pos";
}



// First get ads per cat and subcat
$subcatadcounts = array();
$catadcounts = array();
$sql = "SELECT scat.subcatid, scat.catid, COUNT(*) as adcnt
		FROM $t_ads a
			INNER JOIN $t_subcats scat ON scat.subcatid = a.subcatid AND ($visibility_condn)
			INNER JOIN $t_cats cat ON cat.catid = scat.catid
			INNER JOIN $t_cities ct ON a.cityid = ct.cityid
		WHERE scat.enabled = '1'
			$loc_condn
		GROUP BY a.subcatid";

$res = mysql_query($sql) or die(mysql_error().$sql);

while($row=mysql_fetch_array($res))
{
	$subcatadcounts[$row['subcatid']] = $row['adcnt'];
	$catadcounts[$row['catid']] += $row['adcnt'];
}



// Categories
$sql = "SELECT catid, catname AS catname FROM $t_cats WHERE enabled = '1' $sortcatsql";
$rescats = mysql_query($sql) or die(mysql_error());
$catcount = @mysql_num_rows($rescats);

$percol_short = floor($catcount/$dir_cols);
$percol_long = $percol_short+1;
$longcols = $catcount%$dir_cols;

$i = 0;
$j = 0;
$col = 0;
$thiscolcats = 0;

while($rowcat=mysql_fetch_array($rescats))
{
	if ($j >= $thiscolcats)
	{
		$col++;
		$thiscolcats = ($col > $longcols) ? $percol_short : $percol_long;
		$j = 0;
		
		echo "<td valign=\"top\" width=\"$cell_width%\">";
	}

	$i++;
	$j++;

    /* Begin Version 2.1 */
    $catlink = buildURL("ads", array($xcityid, $rowcat['catid'], $rowcat['catname']));
    /* End Version 2.1 */

	$adcount = 0+$catadcounts[$rowcat['catid']];

?>

	<table border="0" cellspacing="0" cellpadding="0" width="80%" class="dir_cat">
	<tr>
	
   
	     		<th><a href="<?php echo $catlink; ?>"><?php echo $rowcat['catname']; ?></a>
	<?php if($show_cat_adcount) { ?><span class="count">(<?php echo $adcount; ?>)</span><?php } ?>
	
	</th>

	</tr>

<?php

	$sql = "SELECT scat.subcatid, scat.subcatname AS subcatname
	FROM $t_subcats scat
	WHERE scat.catid = $rowcat[catid]
		AND scat.enabled = '1'
	$sortsubcatsql";

	$ressubcats = mysql_query($sql) or die(mysql_error()."<br>$sql");
	/* Begin Version 2.1 */
	$subcatcount = mysql_num_rows($ressubcats);
	/* End Version 2.1 */

	while ($rowsubcat = mysql_fetch_array($ressubcats))
	{
	    /* Begin Version 2.1 */
	    if ($shortcut_categories && $subcatcount == 1 
	            && $rowsubcat['subcatname'] == $rowcat['catname']) {
	        continue;
	    }
	    /* End Version 2.1 */
	    
		$adcount = 0+$subcatadcounts[$rowsubcat['subcatid']];

        /* Begin Version 2.1 */
        $subcat_url = buildURL("ads", array($xcityid, $rowcat['catid'], $rowcat['catname'], 
            $rowsubcat['subcatid'], $rowsubcat['subcatname']));
        /* End Version 2.1 */

?>
		<tr>
		
		<td>
		<a href="<?php echo $subcat_url; ?>"><?php echo $rowsubcat['subcatname']; ?></a>
		<?php if($show_subcat_adcount) { ?><span class="count">(<?php echo $adcount; ?>)</span><?php } ?>
		<br>






		</td>
		</tr>

<?php

	}

?>
	
	</table>
	<br>


<?php

	if($j==$thiscolcats || $i==$catcount) echo "</td>";

}


?>

</tr>



</table>





</div>


