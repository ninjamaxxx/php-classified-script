var popWin;
function popupwindow(url, width, height)
{
 if(popWin)
 {
  popWin.close();
  popWin='';
 }
 popWin=window.open(url,"popWin","toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,directories=no,status=no,width="+ width +",height="+height);
 popWin.moveTo(30, 100);
 popWin.focus();
}
