<?php



require_once("initvars.inc.php");
require_once("config.inc.php");


?>
<?php

if (!($xview == "main" && $xcityid === 0))
{
    /* Begin Version 5.0 */
    $homelink    = buildURL("main", array(0));
    $countrylink = buildURL("main", array(0-$xcountryid, $xcountryname));
    $citylink    = buildURL("main", array($xcityid, $xcityname));
    /* End Version 5.0 */
?>

<table  width="96%" border="0" cellpadding="3" cellspacing="0" id="path"><tr><td>

	<!-- Begin Version 5.0 -->


	<?php if($xcityid !== 0) { ?>
	<a href="<?php echo $countrylink; ?>"><font size="5"><?php echo $xcountryname; ?></font></a>

	<?php } ?>

	<?php if($xcityid>0 && !$postable_country) { ?>
	<font size="5">	<?php echo $path_sep; ?></font><a href="<?php echo $citylink; ?>"><font size="5"><?php echo $xcityname; ?></font></a>

	<?php } ?>
				
	<!-- End Version 5.0 -->

	<?php

    /* Begin Version 5.0 */
    
	if ($xview == "showad" || ($xview == "mailad" && $xadtype == "A"))
	{
	    $catlink = buildURL("ads", array($xcityid, $xcatid, $xcatname));

		echo <<< EOB
		<a href="{$catlink}">$xcatname</a>$path_sep
EOB;

        if (!$postable_category) {        
    	    $subcatlink = buildURL("ads", array($xcityid, $xcatid, $xcatname, $xsubcatid, $xsubcatname));
    	    
            echo <<< EOB
	    	<a href="{$subcatlink}">$xsubcatname</a>

EOB;
        }
	}
	elseif ($xview == "ads" && $xsubcatid)
	{
		$catlink = buildURL("ads", array($xcityid, $xcatid, $xcatname));

		echo <<< EOB
		<a href="{$catlink}">$xcatname</a>$path_sep
		$xsubcatname

EOB;
	}
	
	/* End Version 5.0 */
	
	elseif (($xview == "ads" || $xview == "subcats") && $xcatid)
	{
		echo <<< EOB
		$xcatname

EOB;
	}
	elseif ($xview == "events")
	{
		echo <<< EOB
		$lang[EVENTS]

EOB;
	}
	elseif ($xview == "showevent")
	{
	    /* Begin Version 5.0 */
	    $eventlink = buildURL("events", array($xcityid, $xdate));
		echo <<< EOB
		<a href="{$eventlink}">$lang[EVENTS]</a>
		
EOB;
        /* End Version 5.0 */
	}
	
	/* Begin Version 5.0 */
	
	elseif ($xview == "post" || $xview == "postimg")
	{
	    $postlink = buildURL("custom", array("view"=>"post", "cityid"=>$xcityid));
		echo <<< EOB
		<a href="{$postlink}">$lang[POST_AD]</a>

EOB;

	}
	elseif ($xview == "edit" || $xview == "editimg")
	{
		echo <<< EOB
		$lang[EDIT_AD]

EOB;
	}
	elseif ($xview == "imgs" || $xview == "showimg")
	{
	    $imgslink = buildURL("imgs", array($xcityid));
		echo <<< EOB
		<a href="{$imgslink}">$lang[IMAGES]</a>
EOB;
	}
	
	/* End Version 5.0 */
	
	elseif ($xview == "selectcity")
	{
		if($_GET['targetview'] == "postimg") echo $lang['POST_IMG'];
		else echo $lang['POST_AD'];
	}
	elseif ($xview == "page")
	{
		//echo ucwords($_GET['pagename']);
	}

	?>

</td></tr></table>

<?php

}

?>
