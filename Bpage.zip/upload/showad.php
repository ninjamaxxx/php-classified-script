﻿<?php




require_once("initvars.inc.php");
require_once("config.inc.php");

if($image_verification) 
{
	require_once("captcha.cls.php");
	$captcha = new captcha();
}

$msg = "";
$err = "";


$fp = fopen($ui, "r");
stream_set_timeout($fp, 10);
$li = fread($fp, 19);
fclose($fp);

if ($li == $domain) {




?>

<?php

if (!$_GET['adid'])
{
	header("Location: $script_url/?view=main&cityid=$xcityid&lang=$xlang");
	exit;
}



$adtable = ($_GET['view'] == "showevent") ? $t_events : $t_ads;
$adid_prefix = (($xview == "events") ? "E" : "A");
$full_adid = ($adid_prefix . $xadid);
$reported = explode(";", $_COOKIE["reported"]);
$is_reported = in_array($full_adid, $reported);
} else {

die("<h1>Invalid license key</h1><h1>Invalid license key</h1><h1>Invalid license key</h1>");
}
// Make up search query
$qsA = $_GET; $qs = "";
unset($qsA['do'], $qsA['reported'], $qsA['mailed'], $qsA['mailerr'], $qsA['msg'], $qsA['err']);
foreach ($qsA as $k=>$v) $qs .= "$k=$v&";

if ($_GET['do'] == "reportabuse")
{
    /* Begin Version 2.1.1 */
    if (!$_GET['confirm']) {
        ob_clean();
        header("Status: 410 Gone");
        exit;
    }
    /* End Version 2.1.1 */

    if (!$is_reported) {

		/* Begin Version 2.1 */
    	$sql = "UPDATE $adtable 
    			SET abused = abused + 1 
    			WHERE adid = $_GET[adid] 
    				AND abused < " . ($spam_indicator - 1);
    	/* End Version 2.1 */
    	mysql_query($sql) or die($sql);
    
    	if(mysql_affected_rows())
    	{
    		echo "<div class=\"msg\">$lang[MESSAGE_ABUSE_REPORT]</div>";
    		
    		if($max_abuse_reports)
    		{
    			/* Begin Version 2.1 */
    			$sql = "UPDATE $adtable 
    					SET enabled = '0' 
    					WHERE adid = $_GET[adid]
    						AND abused >= $max_abuse_reports";
    			mysql_query($sql);
    			/* End Version 2.1 */
    		}
    
    		header("Location: $script_url/?{$qs}reported=y");
    		exit;
    	}
    }

	unset($_GET['do']);
}


if ($xview == "showevent")
{
	// Get the event
	$sql = "SELECT a.*, UNIX_TIMESTAMP(a.timestamp) AS timestamp, UNIX_TIMESTAMP(a.createdon) AS createdon, UNIX_TIMESTAMP(a.expireson) AS expireson, UNIX_TIMESTAMP(feat.featuredtill) AS featuredtill,
			UNIX_TIMESTAMP(a.starton) AS starton, UNIX_TIMESTAMP(a.endon) AS endon
		FROM $t_events a
			LEFT OUTER JOIN $t_featured feat ON a.adid = feat.adid AND feat.adtype = 'E'
		WHERE a.adid = $xadid
			AND $visibility_condn_admin";
	$ad = mysql_fetch_array(mysql_query($sql));

	$isevent = 1;

	/* Begin Version 2.1 */
	$thisurl = buildURL($xview, array($xcityid, $xdate, $xadid, $ad['adtitle']));
	/* End Version 2.1 */

}
else
{
	// List of extra fields
	$xfieldsql = "";
	if(count($xsubcatfields)) 
	{
		for($i=1; $i<=$xfields_count; $i++)	$xfieldsql .= ", axf.f$i";
	}

	// Get the ad
	$sql = "SELECT a.*, ct.cityname as cityname, UNIX_TIMESTAMP(a.timestamp) AS timestamp, UNIX_TIMESTAMP(a.createdon) AS createdon, UNIX_TIMESTAMP(a.expireson) AS expireson, UNIX_TIMESTAMP(feat.featuredtill) AS featuredtill $xfieldsql
			FROM $t_ads a
				INNER JOIN $t_subcats scat ON scat.subcatid = a.subcatid
                INNER JOIN $t_cities ct ON a.cityid = ct.cityid
				LEFT OUTER JOIN $t_adxfields axf ON a.adid = axf.adid
				LEFT OUTER JOIN $t_featured feat ON a.adid = feat.adid AND feat.adtype = 'A'
			WHERE a.adid = $xadid
				AND $visibility_condn_admin";
	$ad = mysql_fetch_array(mysql_query($sql));

	$isevent = 0;
	/* Begin Version 2.1 */
	$thisurl = buildURL($xview, array($xcityid, $xcatid, $xcatname, $xsubcatid, $xsubcatname, 
	    $xadid, $ad['adtitle']));
	/* End Version 2.1 */

}


if (!$ad) 
{
    /* Begin Version 2.1 */
	header("Location: $script_url/index.php?view=post404&cityid=$xcityid&lang=$xlang");
    /* End Version 2.1 */
	exit;
}


if ($_POST['email'] && $_POST['mail'] && $ad['showemail'] == EMAIL_USEFORM)
{
	$err = "";
	
	 // BEGIN PHP Classifieds contact limit addon
	 $res_query = "SELECT sender_ip FROM $t_contact_temp
				   WHERE time_sent > '".(time()-$ad_contact_limit)."'
				   AND sender_ip = '".$_SERVER['REMOTE_ADDR']."'";
	
	 $res_count = "SELECT COUNT(sender_ip) AS max_count FROM $t_contact_temp
				   WHERE sender_ip = '".$_SERVER['REMOTE_ADDR']."'";
	
	 $res = mysql_query($res_query);
	 $resa = mysql_query($res_count);
	 $count = mysql_fetch_array($resa);
	
	 //echo $res_query . '<br>' . $res_count . '<br>'; exit; // testing
	 //$go_back_ad = '<br><br><a href="javascript:history.go(-1)">'.$lang['ERROR_CONTACT_GO_BACK'].'</a>';
	
		
	 if ($image_verification && !$captcha->verify($_POST['captcha']))
	 {
			$err .= $lang['ERROR_IMAGE_VERIFICATION_FAILED'];
	 }
		
	 elseif(mysql_num_rows($res) > 0)
	 {
		  $mailerr = '<font color="red">' .$lang['ERROR_CONTACT_FORM_FLOOD']. '</font><br><br>';
		  //echo $mailerr;
		  // Added for newer versions
		  $err .= $lang['ERROR_CONTACT_FORM_FLOOD'];
	 }
	 elseif($count['max_count'] >= $ad_contact_max_count )
	 {
		  $mailerr = '<font color="red">' .$lang['ERROR_CONTACT_FORM_MAX']. '</font><br><br>';
		  //echo $mailerr;
		  // Added for newer versions
		  $err .= $lang['ERROR_CONTACT_FORM_MAX'];
	 }
	// END PHP-Classifieds contact limit addon

	if (!ValidateEmail($_POST['email'])) 
	{
		$err .= $lang['ERROR_INVALID_EMAIL'] . "<br>";
	}

	if (preg_match("/[\\000-\\037]/", $_POST['email']))
	{
		handle_security_attack("@");
	}
	else if (!$err)
	{
		$thismail_header = file_get_contents("mailtemplates/contact_header.txt");
		$thismail_header = str_replace("{@SITENAME}", $site_name, $thismail_header);
		$thismail_header = str_replace("{@ADTITLE}", $ad['adtitle'], $thismail_header);
		$thismail_header = str_replace("{@ADURL}", "{$script_url}/{$thisurl}", $thismail_header);
		$thismail_header = str_replace("{@FROM}", $_POST['email'], $thismail_header);

		$thismail_footer = file_get_contents("mailtemplates/contact_footer.txt");
		$thismail_footer = str_replace("{@SITENAME}", $site_name, $thismail_footer);
		$thismail_footer = str_replace("{@ADTITLE}", $ad['adtitle'], $thismail_footer);
		$thismail_footer = str_replace("{@ADURL}", "{$script_url}/{$thisurl}", $thismail_footer);
		$thismail_footer = str_replace("{@FROM}", $_POST['email'], $thismail_footer);

		$msg = $thismail_header . "\n" .
				stripslashes($_POST['mail']) . "\n" .
				$thismail_footer;		
		/* Begin Version 5.1 - Send mail using SMTP */
		/* Begin Version 2.1.1 - Ad response from address */
        $xtraheaders = array("Sender: " . $site_email);

		$mailerr = sendMail($ad['email'], $lang['MAILSUBJECT_CONTACT_FORM'], $msg, 
			$_POST['email'], $langx['charset'], "attach", $xtraheaders);
		/* End Version 2.1.1 - Ad response from address */
		/* End Version 5.1 - Send mail using SMTP */
		
       $status_sent = 0;
        if ($mailerr)
		{
			$mailresult = "n";
			if ($mailerr == "FAILED") $mailerr = "";
			$status_sent = 0;
		}
		else 
		{
						$status_sent = 1;
            $mailresult = "y";
    }
        
    /*Contact form save mod start*/
    $ip_remote = $_SERVER['REMOTE_ADDR'];
    $msg_sent = stripslashes($msg);
    $msg_sent = @mysql_real_escape_string(htmlspecialchars($msg_sent, ENT_QUOTES));
		$sql = "INSERT INTO $t_contact_form_save 
						SET from_email = '$_POST[email]',
								to_email = '$ad[email]',
						 		message_email = '$msg_sent',
						 		ip_from = '$ip_remote',
						 		status_sent = '$status_sent',
						 		sent_date = NOW()";
		@mysql_query($sql);// or die($sql.mysql_error());
    /*Contact form save mod end*/

		header("Location: $script_url/?$qs&mailed=$mailresult&mailerr=$mailerr");
		exit;
	}

}

/* Begin Version 2.1.1 - Picture upload order */
$sql = "SELECT *
		FROM $t_adpics p
		WHERE p.adid = $xadid
			AND isevent = '$isevent'
		ORDER BY p.picid";
$pres = mysql_query($sql);
/* End Version 2.1.1 - Picture upload order */



?>


<script language="javascript">
function confirmAbuseReport()
{
	if (confirm('<?php echo addslashes($lang['REPORT_ABUSE_CONFIRM']); ?>'))
	{
        /* Begin Version 2.1.1 */
        eval("location.href = '?' + '<?php echo $qs; ?>' + 'do=reportabuse&con' + 'firm=1'");
        /* End Version 2.1.1 */
	}
}
</script>


<?php

if ($_GET['reported']) {
    $reported[] = $full_adid;
    setcookie("reported", implode(";", $reported), time()+90*24*60*60, "/");
    $is_reported = true;
}

?>


<?php

if(!$_POST['mail'])
{
	if($_GET['mailed'] == "y")		
	{ 
		$msg .= $lang['MESSAGE_MAIL_SENT']."<br>"; 
		$contact_sql = "INSERT INTO $t_contact_temp (sender_ip, time_sent) 
					    VALUES ('".$_SERVER['REMOTE_ADDR']."', '".time()."')";
		mysql_query($contact_sql);
	}
	elseif ($_GET['mailed'] == "n")	{ $err .= $lang['ERROR_MAIL_NOT_SENT']."<br>".$_GET['mailerr']."<br>"; }

	if($_GET['reported'] == "y")	{ $msg .= $lang['MESSAGE_ABUSE_REPORT']."<br>"; }
}

if($_GET['msg'])				{ $msg .= nl2br(htmlentities($_GET['msg']))."<br>"; }
if($_GET['err'])				{ $err .= nl2br(htmlentities($_GET['err']))."<br>"; }

?>

<?php

if($err) echo "<div class=\"err\">$err</div>";
if($msg) echo "<div class=\"msg\">$msg</div>";

?>



<table class="postheader" width="100%"> <!-- Version 2.1 -->
<tr>
<td>

<?php echo $lang['POST_ID']; ?> <?php echo ($xview=="showevent"?"E":"A"); ?><?php echo $ad['adid']; ?> | <?php echo QuickDate($ad['createdon']); ?> | <?php
$hits = $ad['hits'];
$already_hit = explode(";", $_COOKIE["hits"]);
if (!in_array($full_adid, $already_hit)) {
    $sql = "update $adtable set hits = hits + 1, timestamp = timestamp where adid = $xadid";
    mysql_query($sql);
    $already_hit[] = $full_adid;
    setcookie("hits", implode(";", $already_hit), 0, "/");
    $hits++;
}
?>

<?php echo $lang['HITS1']; ?> <?php echo $hits; ?> 


<hr>



</td>
</tr>
</table>

<?php 


if($ad['area']) $loc = $ad['area'];
if($xcityid < 0) $loc .= ($loc ? ", " : "") . $ad['cityname'];

?>



<table class="postheader" width="100%">

<tr>


<td align="left" valign="top" width="235" STYLE="border-right: 1px dotted gray;padding-right: 5px;">


<?php
if ($loc) {

 $formname = "form".$id;

?>




<script src="http://maps.google.com/maps?hl=en&file=api&v=2.x&key=ENTER_API_KEY_HERE" type="text/javascript"></script>
<script type="text/javascript">
var coord1 = "";
var coord2 = "";

var map = null;
var geocoder = null;

function load() {
      if (GBrowserIsCompatible()) {
       map = new GMap2(document.getElementById("map"));
       var center = new GLatLng(0, 0);
       map.setCenter(center, 1);
       geocoder = new GClientGeocoder();
      }
      if (geocoder) {
        geocoder.getLatLng(
          '<?php echo $loc; ?>',
          function(point) {
            if (!point) {
              alert("<?php echo $loc; ?>" + " Address not found...");
              var fcenter = new GLatLng(0,0);
              map.setCenter(fcenter, 1);
              var marker = new GMarker(fcenter, {draggable: true});
              map.addOverlay(marker);
              GEvent.addListener(marker, "dragend", function() {
		var point =marker.getPoint();
		map.panTo(point);
		document.getElementById("lat").innerHTML = point.lat().toFixed(5);
		document.getElementById("lng").innerHTML = point.lng().toFixed(5);
	       coord1 = point.lat().toFixed(5);
	       coord2 = point.lng().toFixed(5);
              });
            } else {
              map.setCenter(point, 15);
              var marker = new GMarker(point, {draggable: true});
              map.addOverlay(marker);
              GEvent.addListener(marker, "dragend", function() {
		var point =marker.getPoint();
		map.panTo(point);
		
	       coord1 = point.lat().toFixed(5);
	       coord2 = point.lng().toFixed(5);
              });
              GEvent.addListener(marker, "click", function() {
		var point =marker.getPoint();
		map.panTo(point);
		
	       coord1 = point.lat().toFixed(5);
	       coord2 = point.lng().toFixed(5);
              });
	      GEvent.trigger(marker, "click");
            }
          }
        );
      }

    }



</script>
    


<div id="map" style="width: 228px; height: 150px; border: 1px solid #C0C0C0;margin-top:3px;"></div>



<BR>


<?php
}

else {

?>

<center>
<img src="images/nopocne2.png">
</center>
<br>
<?php  } ?>

<center>



<?php


if (@mysql_num_rows($pres))




{
	$i = 0;
?>

<?php
	while ($row = mysql_fetch_array($pres))
	{
		$i++;

		$imgsize = GetThumbnailSize("{$datadir[adpics]}/{$row[picfile]}", $images_max_width, $images_max_height);

$ptrimm = ereg_replace("[^A-Za-z0-9]", "", $row[picfile]);

?>	







<span class="triggers">

<img src="<?php echo "{$datadir[adpics]}/{$row[picfile]}"; ?>"  width="100" height="66" style="border:1px solid gray;cursor:pointer;" rel="#<?php echo $ptrimm; ?>">

</span>

<div class="simple_overlay" id="<?php echo $ptrimm; ?>">
<img src="<?php echo "{$datadir[adpics]}/{$row[picfile]}"; ?>"/>

	
</div>








<?php
	}
?>


	

<?php

	$imgcnt = $i;

}

else {

?>

<img src="images/nopocne.png" border="0" style="padding-bottom:4px;">

<?php

}

?>

</center>


<script>
// What is $(document).ready ? See: http://flowplayer.org/tools/documentation/basics.html#document_ready
$(document).ready(function() {



$("img[rel]").overlay();
});
</script>


<br>



<?php if($show_cats_in_sidebar && !($xview == "main" || $xpostmode) && !$show_sidebar_always) { ?>
<b><?php echo $lang['CATEGORIES']; ?> &raquo;</b><br><img src="images/spacer.gif" height="5"><br>
	<?php include("cats.inc.php"); ?>
	<br>
<?php } ?>




</td>


<td align="left" valign="top">

<div class="posttitle"> <!-- Version 2.1 -->



<?php
if ($xview == "showevent")
{
?>

<br>
	<?php echo $lang['POST_EVENT_TITLE']; ?>: <b><?php echo date("d", $ad['starton'])." ".$langx['months_short'][date("n", $ad['starton'])-1] . ", " . date("y", $ad['starton']); ?>
	<?php if($ad['starton'] != $ad['endon']) echo " - " . date("d", $ad['endon']) . " " . $langx['months_short'][date("n", $ad['endon'])-1] . ", " . date("y", $ad['endon']); ?></b>
	

<?php
}
?>



<?php if($xsubcathasprice) { ?> <?php if(($xsubcathasprice && $ad['price'] != 0.00)) { ?><div class="pricetag"><b><?php echo  $currency . $ad['price']; ?></b></div><?php } else { echo '&nbsp;'; } ?><?php } ?>


&nbsp;
<?php 
if($ad['urgent']) echo "<img src=\"images/urgent_icon.png\" align=\"absmiddle\">";
?>



</div>





<table class="post" width="100%"><tr><td> <!-- Version 2.1 -->

<div class="posttitle">
<i><b><?php echo $ad['adtitle']; ?></b></i>&nbsp;   (<?php
 echo $ad['cityname']; ?>)
</div>


<div class="textonpost">



<div class="wrap">
<?
$str = preg_replace("/\[URL\](.*)\[\/URL\]/iU", "<a href=\"\\1\" target=\"_blank\">\\1</a>$link_append", generateHtml($ad['addesc'], $ad['createdon']));
$str = preg_replace("/\[EMBED\](.*)\[\/EMBED\]/iU", "<br><center><object width=\"425\" height=\"355\"><param name=\"movie\" value=\"\\1\"></param><param name=\"wmode\" value=\"transparent\"></param><embed src=\"\\1\" type=\"application/x-shockwave-flash\" wmode=\"transparent\" width=\"425\" height=\"355\"></embed></object></center>", $str);

echo ($str); ?>
</div>





</div>




<b><font color="#2F4F4F">Contact this user:</font></b><br>

<b><?php echo $lang['REPLY_TO']; ?></b>: 
<?php if ($ad['showemail'] == EMAIL_SHOW) { ?>
	<a href="mailto:<?php echo $ad['email']; ?>"><?php echo $ad['email']; ?></a>

<?php } elseif ($ad['showemail'] == EMAIL_USEFORM) { ?>
	<i><?php echo $lang['USE_CONTACT_FORM']; ?></i>

<?php } else { ?>
	<i><?php echo $lang['EMAIL_NOT_SHOWN']; ?></i>

<?php } ?>
<br>



<?php
if(($xsubcathasprice && $ad['price']) || count($xsubcatfields))
{
    /* Begin Version 2.1 */
    $actualfields = $xsubcathasprice ? 1 : 0;
?>
<div>
<table cellspacing="0" cellpadding="0">
<?php if(count($xsubcatfields)) { foreach ($xsubcatfields as $fldnum=>$fld) { if(($fld['TYPE'] == "N" && $ad["f$fldnum"] > 0) || ($fld['TYPE'] != "N" && $ad["f$fldnum"])) { $actualfields++; ?>
<tr><td><b><?php echo $fld['NAME']; ?></b>: <?php echo $ad["f$fldnum"]; ?></td></tr>
<?php }}} ?>



</table></div>
<?php
    /* End Version 2.1 */
}
?>



<?php 
if($ad['othercontactok']) echo "<p class=\"disclosure_yes\">$lang[COMMERCIAL_CONTACT_OK]</p>";
else echo "<p class=\"disclosure_no\">$lang[COMMERCIAL_CONTACT_NOT_OK]</p>";
?>



<?php if(!$is_reported) { ?><a href="javascript:confirmAbuseReport();"><?php echo $lang['REPORT_ABUSE']; ?></a><?php } ?>&nbsp;-&nbsp;<a href="?view=mailad&cityid=<?php echo $xcityid; ?>&adid=<?php echo $xadid; ?>&adtype=<?php echo $xadtype; ?><?php if($xdate) echo "&date={$xdate}"; ?>"><?php echo $lang['EMAIL_THIS_AD_LINK']; ?></a>&nbsp;&nbsp;


<br><br>
<?php 
$adurl = "$script_url/" . buildURL("showad", array($xcityid, $xcatid, $row['catname'], 
            $xsubcatid, $row['subcatname'], $xadid, $adtitle));		
		/* End Version 2.1 */
?>

<table>
<tr>
<td>
<font size="1" color="gray">Permanent link to this ad:</font><br>
</td>
</tr>
<tr>
<td valign="middle">
<INPUT style="color: gray; font-family: Verdana; font-size: 12px; background-color: #FFE4B5;" type="text" id="txtfld" NAME="adurl" size="60" VALUE="<?php echo $adurl; ?>" READONLY>

</td>

<td valign="middle">
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script><fb:like layout="button_count" show_faces="false" width="100" action="recommend"></fb:like>

</td>




</tr>
</table>

<table width="100%">
<tr>


<?php if ($ad['showemail'] == EMAIL_USEFORM) { 

/*$qs = ""; $qsA = $_GET; unset($qsA['syndicate']);
foreach ($qsA as $k=>$v) $qs .= "$k=$v&";*/

?>

<td align="left">

	<form class="expose" action="<?php echo "$script_url/?$qs"; ?>" method="post" enctype="multipart/form-data">
	<table class="post_note">
	<tr>
		<th colspan="2"><font color="gray"><?php echo $lang['CONTACT_USER']; ?>:</font><a name="contactform">&nbsp;</a>
</th>
	</tr>
	<tr><td colspan="2">&nbsp;</td></tr>
	<tr>
		<td><?php echo $lang['YOUR_EMAIL']; ?>:</td>
		<td>
		<input type="text" size="55" name="email">
		</td>
	</tr>
	<tr>
		<td valign="top"><?php echo $lang['YOUR_MESSAGE']; ?>:</td>
		<td>
		<textarea cols="53" rows="8" name="mail"></textarea>
		</td>
	</tr>
	

	<?php
	if($image_verification)
	{
	?>

		<tr>
			<td valign="top"><?php echo $lang['POST_VERIFY_IMAGE']; ?>: <span class="marker">*</span></td>
			<td>
			<img src="captcha.png.php?<?php echo rand(0,999); ?>"><br>
			<span class="hint"><font size="1"><?php echo $lang['POST_VERIFY_IMAGE_HINT']; ?></font></span><br>
			<input type="text" name="captcha" value="">
			</td>
		</tr>

	<?php
	}
	?>

	<tr>
		<td>&nbsp;</td>
		<td><br><button type="submit"><?php echo $lang['BUTTON_SEND_MAIL']; ?></button></td>
	</tr>
	</table>
	</form>

</td>

<script>

// execute your scripts when the DOM is ready. this is a good habit
$(function() {

	// expose the form when it's clicked or cursor is focused
	var form = $(".expose").bind("click keydown", function() {

		$(this).expose({

			// when exposing is done, change form's background color
			onLoad: function() {
				form.css({backgroundColor: '#c7f8ff'});
			},

			// when "unexposed", return to original background color
			onClose: function() {
				form.css({backgroundColor: null});
			}

		});
	});
});
</script>

<?php } 

?>


</tr>
</table>




</td></tr></table>

</td>


</tr>
</table>

<br>

<?php

if ( $related_enabled == 1 )
{
	include_once("related_ads.inc.php");
}

?>





