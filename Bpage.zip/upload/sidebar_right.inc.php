<center>
To remove this message please edit file sidebar_right.inc.php or disable the right sidebar in configuration file.
<br>
<br>
Want to display the latest featured ads in the sidebar like Facebook site? Visit www.php-classifieds.com and download the featured ads addon.
</center>




