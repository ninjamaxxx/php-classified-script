<?php

$script_url = "http://www.yvszxdf.com/test/dfhgdfg";
$bodytag = str_replace("http://", "", $script_url);
$domain = $bodytag;

$domain = substr($domain, 0, strpos($domain, "/"));
echo $domain;
?>
