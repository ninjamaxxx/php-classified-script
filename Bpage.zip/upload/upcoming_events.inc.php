<?php


require_once("initvars.inc.php");
require_once("config.inc.php");

?>
<?php
if($upcoming_events_count)
{
?>


<!-- Begin Version 2.1 -->

<table cellspacing="0" cellpadding="0"  width="100%">

<tr>
<td colspan="2" style="padding:2px;">
<center><font color="#4682B4"><b><?php echo $lang['PRED_SOB']; ?></b></font></center>
</td>
</tr>


<!-- End Version 2.1 -->


<?php
	$sql = "SELECT a.*, UNIX_TIMESTAMP(a.starton) AS starton_ts, UNIX_TIMESTAMP(a.endon) AS endon_ts, feat.adid AS isfeat,
				COUNT(*) AS piccount, p.picfile AS picfile, ct.cityname
			FROM $t_events a
				INNER JOIN $t_cities ct ON a.cityid = ct.cityid
				LEFT OUTER JOIN $t_adpics p ON a.adid = p.adid AND p.isevent = '1'
				LEFT OUTER JOIN $t_featured feat ON a.adid = feat.adid AND feat.adtype = 'E' AND feat.featuredtill >= NOW()
			WHERE $visibility_condn
				
				AND a.starton >= NOW()
			GROUP BY a.adid
			ORDER BY a.starton ASC
			LIMIT $upcoming_events_count";
	$res_latest = mysql_query($sql) or die($sql.mysql_error());

	$css_first = "_first";
	while($row = mysql_fetch_array($res_latest))
	{
		
		$event_start_date = date("Y-m-d", $row['starton_ts']);

        /* Begin Version 5.0 */
        $url = buildURL("showevent", array($xcityid, $event_start_date, $row['adid'], $row['adtitle']));
        /* End Version 5.0 */

?>


		<?php 
		/*if($row['isfeat']) 
		{
			//$feat_class = "class=\"featured\"";
			$feat_img = "<img src=\"images/featured.gif\" align=\"absmiddle\">";
		} 
		else 
		{ 
			//$feat_class = "";
			$feat_img = "";
		}*/

		if($row['picfile']) 
		{
			$picfile = $row['picfile'];
			$imgsize = GetThumbnailSize("{$datadir[adpics]}/{$picfile}", $tinythumb_max_width, $tinythumb_max_height);
		}
		else 
		{
			$picfile = "no_image.png";
		}
		?>

		<tr>
			<td style="margin:2px;padding:2px;">
			

<table width="30" cellpadding="0" cellspacing="0">
			<tr>
			<td align="center" style="border-top-left-radius: 5px 5px;border-top-right-radius: 5px 5px;border:1px solid OrangeRed ;background-color:white;font-size:10px;color:black;padding:1px;">
			<b><?php echo date("d", $row['starton_ts']); ?></b>
			</td>
			</tr>
			<tr>
			<td align="center" style="border-bottom-left-radius: 5px 5px;border-bottom-right-radius: 5px 5px;border:1px solid OrangeRed ;background-color:OrangeRed ;font-size:9px;color:white;padding:1px;">
			
			<b><?php echo $langx['months_short'][date("n", $row['starton_ts'])-1]; ?></b>
			
			</td>
			
			</tr>
			</table>



			</td>
			

			


			<td style="font-size:10px;padding:1px;">
			<a href="<?php echo $url; ?>" <?php echo $feat_class; ?> target="_top"><?php echo $row['adtitle']; ?></a><br>
			
			<?php 
			$loc = $row['cityname'];
		
			if($loc) echo "<font color=\"gray\">$loc</font>";
			?>			
			</td>

		
			
		</tr>

<?php
		$css_first = "";
	}
?>

<tr>
<td COLSPAN="2" STYLE="PADDING: 2PX;">
<center><div><a href="/0/events">View All Events</a></div></center>

<a href="?view=selectcity&targetview=post&cityid=0&lang=en">
<CENTER><div><u><?php echo $lang['DOB_SOB']; ?></u></div></CENTER>
</a>
<br>
</td>
</tr>

</table>


<?php
}
?>