<?php




$app_name		= "PHP Classifieds";
$app_ver		= "2.1.1";
$app_fullname	= "$app_name $app_ver";

?>